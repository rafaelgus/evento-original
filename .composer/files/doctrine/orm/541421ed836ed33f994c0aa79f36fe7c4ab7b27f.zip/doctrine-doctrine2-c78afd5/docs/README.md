# Doctrine ORM Documentation

## How to Generate

1. Run ./bin/install-dependencies.sh
2. Run ./bin/generate-docs.sh

It will generate the documentation into the build directory of the checkout.
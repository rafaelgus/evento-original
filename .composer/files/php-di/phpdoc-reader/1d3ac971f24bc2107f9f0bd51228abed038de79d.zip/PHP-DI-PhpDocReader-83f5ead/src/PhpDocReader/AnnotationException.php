<?php

namespace PhpDocReader;

/**
 * @author Matthieu Napoli <matthieu@mnapoli.fr>
 */
class AnnotationException extends \Exception
{
}

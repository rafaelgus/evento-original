<?php

namespace DI\Definition\Exception;

/**
 * Exception in the definitions using annotations.
 *
 * @author Matthieu Napoli <matthieu@mnapoli.fr>
 */
class AnnotationException extends DefinitionException
{
}

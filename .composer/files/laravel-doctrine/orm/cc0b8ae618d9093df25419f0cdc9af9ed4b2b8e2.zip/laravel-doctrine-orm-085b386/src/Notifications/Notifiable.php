<?php

namespace LaravelDoctrine\ORM\Notifications;

use Illuminate\Notifications\RoutesNotifications;

trait Notifiable
{
    use RoutesNotifications;
}

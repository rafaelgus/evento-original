<?php

namespace LaravelDoctrine\ORM\Exceptions;

use RuntimeException;

class DriverNotRegistered extends RuntimeException
{
}

<?php

namespace LaravelDoctrine\ORM\Exceptions;

use ErrorException;

class CouldNotExtend extends ErrorException
{
}

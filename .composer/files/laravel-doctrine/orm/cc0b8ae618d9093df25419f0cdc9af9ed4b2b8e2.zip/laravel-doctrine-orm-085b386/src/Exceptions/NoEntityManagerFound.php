<?php

namespace LaravelDoctrine\ORM\Exceptions;

use LogicException;

class NoEntityManagerFound extends LogicException
{
}

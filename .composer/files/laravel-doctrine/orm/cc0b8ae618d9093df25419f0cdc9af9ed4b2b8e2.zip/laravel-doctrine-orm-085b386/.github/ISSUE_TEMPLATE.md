Please prefix your issue with one of the following: [BUG] [PROPOSAL] [QUESTION].

### Package version, Laravel version

### Expected behaviour

### Actual behaviour

### Steps to reproduce the behaviour
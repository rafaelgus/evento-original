<?php

namespace LaravelDoctrine\Migrations\Exceptions;

use InvalidArgumentException;

class MigrationVersionException extends InvalidArgumentException
{
}

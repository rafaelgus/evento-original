# Laravel Doctrine Migrations

<img src="https://cloud.githubusercontent.com/assets/7728097/9831721/1ec0fdbc-5962-11e5-8c80-6f03f8275fbd.jpg"/>

[![GitHub release](https://img.shields.io/github/release/laravel-doctrine/migrations.svg?style=flat-square)](https://packagist.org/packages/laravel-doctrine/migrations)
[![Travis](https://img.shields.io/travis/laravel-doctrine/migrations.svg?style=flat-square)](https://travis-ci.org/laravel-doctrine/migrations)
[![StyleCI](https://styleci.io/repos/39036028/shield)](https://styleci.io/repos/39036028)
[![Scrutinizer](https://img.shields.io/scrutinizer/g/laravel-doctrine/migrations.svg?style=flat-square)](https://github.com/laravel-doctrine/migrations)
[![Packagist](https://img.shields.io/packagist/dm/laravel-doctrine/migrations.svg?style=flat-square)](https://packagist.org/packages/laravel-doctrine/migrations)
[![Packagist](https://img.shields.io/packagist/dt/laravel-doctrine/migrations.svg?style=flat-square)](https://packagist.org/packages/laravel-doctrine/migrations)

*Doctrine Migrations for Laravel*

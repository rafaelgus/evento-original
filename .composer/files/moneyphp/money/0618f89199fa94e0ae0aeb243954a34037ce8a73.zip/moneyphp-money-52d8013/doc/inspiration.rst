Inspiration
===========

* https://github.com/RubyMoney/money
* http://css.dzone.com/books/practical-php-patterns/basic/practical-php-patterns-value
* http://www.codeproject.com/KB/recipes/MoneyTypeForCLR.aspx
* http://stackoverflow.com/questions/1679292/proof-that-fowlers-money-allocation-algorithm-is-correct
* http://timeandmoney.sourceforge.net/
* http://www.joda.org/joda-money/
* http://en.wikipedia.org/wiki/Currency_pair
* https://github.com/RubyMoney/eu_central_bank
* http://en.wikipedia.org/wiki/ISO_4217

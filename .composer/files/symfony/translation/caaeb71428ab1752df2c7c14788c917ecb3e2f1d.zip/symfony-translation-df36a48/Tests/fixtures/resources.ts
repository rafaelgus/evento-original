<?xml version="1.0" encoding="utf-8"?>
<TS>
  <context>
    <name>resources</name>
    <message>
      <source>foo</source>
      <translation>bar</translation>
    </message>
  </context>
</TS>

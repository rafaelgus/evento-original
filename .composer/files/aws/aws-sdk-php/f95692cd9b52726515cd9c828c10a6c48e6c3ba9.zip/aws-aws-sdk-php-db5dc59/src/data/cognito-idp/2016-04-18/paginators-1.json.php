<?php
// This file was auto-generated from sdk-root/src/data/cognito-idp/2016-04-18/paginators-1.json
return [ 'pagination' => [],];

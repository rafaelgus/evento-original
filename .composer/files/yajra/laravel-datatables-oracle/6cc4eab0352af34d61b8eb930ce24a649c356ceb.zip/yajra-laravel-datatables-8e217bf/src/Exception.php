<?php

namespace Yajra\Datatables;

class Exception extends \Exception
{
}
